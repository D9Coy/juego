class Configuracion():
	def __init__(self, pantalla, sonido):