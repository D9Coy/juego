class NIVEL:
	def __init__(self, nivel, mapa, multimedia):
		self.nivel=nivel
		self.mapa=mapa
		self.multimedia=multimedia

	def getParedes(self):
		lista=[]
		for m in mapa:
			pass